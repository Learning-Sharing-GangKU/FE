// src/app/home/page.tsx

"use client"; // ✅ 이거 빠지면 에러 발생할 수 있음 (특히 next 13+에서 Client Component일 경우)

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Plus, Home, List, User, Users } from "lucide-react";
import Link from "next/link";

const HomePage = () => {
  const renderGroupSection = (title: string) => (
    <div className="mb-6">
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <div className="flex items-center">
        <Button variant="outline" size="icon" className="mr-2">
          <ArrowLeft size={16} />
        </Button>

        <Card className="flex-1 h-40 flex items-center justify-center">
          <CardContent>
            <div className="text-center text-gray-500">사진</div>
          </CardContent>
        </Card>

        <Button variant="outline" size="icon" className="ml-2">
          <ArrowRight size={16} />
        </Button>
      </div>
      <p className="text-center text-sm text-muted-foreground mt-1">모임 제목</p>
    </div>
  );

  return (
    <div className="flex flex-col h-screen justify-between px-4 py-6">
      {/* 상단 바 */}
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">홈</h1>
        <Link href="/login" className="text-sm text-blue-500 font-medium">
          로그인
        </Link>
      </div>

      {/* 모임 섹션 */}
      <div className="flex-1 overflow-y-auto">
        {renderGroupSection("추천 모임")}
        {renderGroupSection("최신 모임")}
        {renderGroupSection("인기 모임")}
      </div>

      {/* 하단 네비게이션 */}
      <nav className="flex justify-between items-center border-t pt-3 px-2 text-xs">
        <Link href="/" className="flex flex-col items-center text-blue-500">
          <Home size={20} /> 홈
        </Link>
        <Link href="/category" className="flex flex-col items-center">
          <List size={20} /> 카테고리
        </Link>
        <Link href="/create" className="flex flex-col items-center">
          <Plus size={20} /> 모임 생성
        </Link>
        <Link href="/manage" className="flex flex-col items-center">
          <Users size={20} /> 모임 관리
        </Link>
        <Link href="/profile" className="flex flex-col items-center">
          <User size={20} /> 내 프로필
        </Link>
      </nav>
    </div>
  );
};

export default HomePage;